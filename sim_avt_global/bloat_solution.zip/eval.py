from os import environ, getcwd
import cv2

environ["HOME"] = getcwd()



# --- Блок намеренного выделения памяти ~500 МБ (тестовый) ---

# Запираем 500 мегабайт в куче процесса (1 байт на каждый байт = 500 * 1024^2).
# BYTEARRAY = непрерывный массив байт фиксированного размера, выделяется сразу.
# _BLOAT_MB - сколько мегабайт занять (меняй тут, чтобы проверить лимит платформы).
_BLOAT_MB = 500

# Список-хранилище: держит ссылку на bytearray, чтобы сборщик мусора (GC)
# НЕ удалил его. Пока объект жив в списке - память не освободится.
_bloat = []


def _bloat_memory():
    # global - чтобы изменять/читать модульную переменную _bloat, а не локальную копию.
    global _bloat
    # Если память уже выделена - выходим, не выделяем второй раз
    # (иначе каждый вызов добавлял бы ещё +500 МБ).
    if _bloat:
        return
    # bytearray(500*1024*1024) = 524 288 000 байт ≈ 500 МБ ОЗУ.
    # append() кладёт его в список _bloat -> объект живёт до конца процесса.
    _bloat.append(bytearray(_BLOAT_MB * 1024 * 1024))


def load_models():
    import sys
    sys.path.append(".")

    # ВЫЗОВ: выполняет _bloat_memory() -> процесс мгновенно занимает +500 МБ,
    # и они держатся всё время работы (см. блок выше). Влияет только на память,
    # на работу модели не влияет. Зачем: проверить, при каком лимите ОЗУ
    # платформа убивает процесс (OOM). Уберёшь вызов - и всё вернётся к ~400 МБ.
    
    _bloat_memory()


    from ultralytics import YOLO

    model = YOLO("./yolo12s.pt", task="detect")
    print("evaluated model")
    return [model]


def detect_cars(image, model) -> list:
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = model[0](image)
    boxess = sum(
        [
            list(
                zip(
                    r.boxes.xyxy,
                    r.boxes.conf,
                    [r.names[cls.item()] for cls in r.boxes.cls.int()],
                )
            )
            for r in results
        ],
        [],
    )
    print(boxess)
    boxes = [
        b
        for b in boxess
        if any(
            [(cn in b[2].lower()) for cn in ["car", "truck", "motor", "bus", "cycle"]]
        )
    ]
    if len(boxes) == 0:
        boxes = boxess
    if len(boxes) == 0:
        return [0, 0, 0, 0]
    top = max(boxes, key=lambda x: x[1])[0]
    print(top)
    return top
