from os import environ, getcwd
import cv2

environ["HOME"] = getcwd()

def load_models():
    import sys
    sys.path.append(".")
    from ultralytics import YOLO

    model = YOLO("./yolo12s.pt", task="detect")
    print("evaluated model")
    return [model]


def detect_cars(image, model) -> list:
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = model[0](image)
    boxess = sum(
        [
            list(
                zip(
                    r.boxes.xyxy,
                    r.boxes.conf,
                    [r.names[cls.item()] for cls in r.boxes.cls.int()],
                )
            )
            for r in results
        ],
        [],
    )
    print(boxess)
    boxes = [
        b
        for b in boxess
        if any(
            [(cn in b[2].lower()) for cn in ["car", "truck", "motor", "bus", "cycle"]]
        )
    ]
    if len(boxes) == 0:
        boxes = boxess
    if len(boxes) == 0:
        return [0, 0, 0, 0]
    top = max(boxes, key=lambda x: x[1])[0]
    print(top)
    return top
